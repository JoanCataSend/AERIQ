<?php
// Configuración privada de remitente para PHP mail() (opcional).
// Si prefieres SMTP, crea SMTPConfig.php en su lugar y elimina este archivo.
// Este archivo está ignorado por Git.

return [
    'from_email' => 'codigonorte.aeriq@gmail.com',
    'from_name' => 'AERIQ',
];
