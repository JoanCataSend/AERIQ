<?php
// SMTP de Gmail. Sustituye el marcador por una contraseña de aplicación de Google.
return [
    'host' => 'smtp.gmail.com',
    'port' => 587,
    'username' => 'codigonorte.aeriq@gmail.com',
    'password' => 'jwxx wdji kknp uhbt',
    'encryption' => 'tls',
    'from_email' => 'codigonorte.aeriq@gmail.com',
    'from_name' => 'AERIQ',
];
