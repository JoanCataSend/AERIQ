<?php
// Configuración privada de MariaDB/MySQL para AERIQ.
// Rellena los valores reales en tu servidor. Este archivo está ignorado por Git.

return [
    'host' => 'localhost',
    'port' => 3306,
    'database' => 'ldiamur_proyecto',
    'user' => 'ldmp',
    'password' => 'LdmP&31_Bio',
];
