<?php

return [
    // Normalmente es localhost en Plesk, pero usa el host mostrado por tu servidor.
    'host' => 'localhost',

    // Puerto estándar de MariaDB/MySQL salvo que Plesk indique otro.
    'port' => 3306,

    // IMPORTANTE: usa el nombre COMPLETO que muestre Plesk.
    'database' => 'jcatsen_pbio',

    // IMPORTANTE: usa el nombre COMPLETO que muestre Plesk.
    'user' => 'jcatsen_pbio',

    // Contraseña del usuario de base de datos creado en Plesk.
    'password' => '^0MLTfgunrqp#1m1'
];
